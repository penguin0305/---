- Adventure RPG Essentials Music Pack by Chris Kohler -

Thank you for downloading this music pack!
This ZIP file contains two kinds of Audio files:

1. Audio files (in folder 'Cuts') which are already cut to loop seamlessly and indefinitely. Every track has two files (a and b). Track a is to be played first. Track b is to be played second and can be looped indefinetely, because it contains the reverb tail from the end of track a. This reverb tail is essential for a realistic and seamless transition at the end of the loop. If only track b was to be played, right in the beginning you would hear reverb from music that has not been played before. For some tracks this might go unnoticed, but for others, especially the louder ones, this is clearly audible. This is why there are two audio files for every track. To give you the best quality loops possible.

2. Already looped previews that give you a impression of how the music will sound when implemented into your game.

For your convenience all files come as WAV as well as MP3. 

If you have any questions feel free to contact me. I am also available to compose custom music for your game.

Best wishes,
Chris Kohler

Email: 	chris@music-for-rpgs.com
Web: 	music-for-rpgs.com