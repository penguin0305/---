using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
	[Header("Move")]
	[SerializeField] private float moveSpeed = 5f;
	public Vector2 moveInput;

	[Header("Jump")]
	[SerializeField] private float jumpForce = 12f;
	[SerializeField] private int maxJumpCount = 2;
	private int currentJumpCount;
	private bool jumpRequested;

	[Header("GroundCheck")]
	[SerializeField] private Transform groundCheck;
	[SerializeField] private float groundCheckRadius = 0.2f;
	[SerializeField] private LayerMask groundLayer;
	public bool isGrounded;

	[Header("Dash")]
	[SerializeField] private float dashSpeedMultiplier = 1.5f;
	private bool isDashing;

	private Rigidbody2D rb;
	private void Awake()
	{
		rb = GetComponent<Rigidbody2D>();
	}

	private void Start()
	{
		currentJumpCount = 0;
		jumpRequested = false;
	}

	private void Update()
	{
		CheckGround();

		if (jumpRequested)
		{
			Jump();
			jumpRequested = false;
		}
	}

	private void FixedUpdate()
	{
		MoveHorizontal();
	}

	private void CheckGround()
	{
		isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

		if (isGrounded)
			currentJumpCount = 0;
	}

	public void RequestMove(Vector2 input)
	{
		moveInput = input;
	}

	public void RequestJump()
	{
		jumpRequested = true;
	}

	public void RequestDash(bool isPressed)
	{
		isDashing = isPressed;
	}

	private void MoveHorizontal()
	{
		float speed = moveSpeed;

		if (isDashing)
			speed *= dashSpeedMultiplier;
		rb.linearVelocityX = moveInput.x * speed;
	}

	private void Jump()
	{
		if (isGrounded || currentJumpCount < maxJumpCount)
		{
			rb.linearVelocityY = jumpForce;
			currentJumpCount++;
		}
	}
}
