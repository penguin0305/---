using UnityEngine;
using SupanthaPaul;
public class PauseMenuManager : MonoBehaviour
{
    public GameObject pauseMenuUI;

    private bool isPaused = false;

    [SerializeField] private AudioSource BGM;
    void Start()
    {
        // 3. ���� ���� �ÿ��� �׻� �޴��� �����ֵ��� ��
        if (pauseMenuUI != null)
        {
            pauseMenuUI.SetActive(false);
        }   
    }

    void Update()
    {
        if (InputSystem.Pause())
        {
            if (isPaused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }
    }

    public void Resume()
    {
        if (pauseMenuUI != null)
        {
            pauseMenuUI.SetActive(false); // UI �����
        }
        Time.timeScale = 1f;
        isPaused = false;
        BGM.UnPause();
        Debug.Log("���� �簳");
    }

    void Pause()
    {
        if (pauseMenuUI != null)
        {
            pauseMenuUI.SetActive(true);
        }
        Time.timeScale = 0f;
        isPaused = true;
        BGM.Pause();
        Debug.Log("���� �Ͻ� ����");
    }
}